#include "RTG.h"
#include "DATA.h"
#include "Funcs.h"

void serialize_data(const Data* data, uint8_t* buffer) {
    memcpy(buffer, &data->x, sizeof(data->x));
    memcpy(buffer + sizeof(data->x), &data->y, sizeof(data->y));
    memcpy(buffer + sizeof(data->x) + sizeof(data->y), &data->opp, sizeof(data->opp));
    memcpy(buffer + sizeof(data->x) + sizeof(data->y) + sizeof(data->opp), &data->result, sizeof(data->result));
}

void deserialize_data(const uint8_t* buffer, Data* data) {
    memcpy(&data->x, buffer, sizeof(data->x));
    memcpy(&data->y, buffer + sizeof(data->x), sizeof(data->y));
    memcpy(&data->opp, buffer + sizeof(data->x) + sizeof(data->y), sizeof(data->opp));
    memcpy(&data->result, buffer + sizeof(data->x) + sizeof(data->y) + sizeof(data->opp), sizeof(data->result));
}

void Handle_SPI_TxRxCplt() {
    // Deserialize the received Data
    Data received_data;
    deserialize_data(rx_buf, &received_data);

    // Update previous_data with the latest received data
    previous_data = received_data;

    // Print received Data for debugging
    printf("Received Data: x = %d, y = %d, opp = %c, result = %lu\n\r",
            received_data.x, received_data.y, (char)received_data.opp, received_data.result);

    // Calculate the result based on the operator
    switch (previous_data.opp) {
        case '+':
            previous_data.result = previous_data.x + previous_data.y;
            break;
        case '-':
            previous_data.result = previous_data.x - previous_data.y;
            break;
        case '*':
            previous_data.result = previous_data.x * previous_data.y;
            break;
        case '/':
            // Check for division by zero
            if (previous_data.y != 0) {
                previous_data.result = previous_data.x / previous_data.y;
            } else {
                // Handle division by zero
                printf("Error: Division by zero.\n\r");
                previous_data.result = 0; // Set result to 0 or handle it as needed
            }
            break;
        default:
            printf("Error: Unknown operator.\n\r");
            previous_data.result = 0; // Default to 0 or handle as needed
            break;
    }

    // Serialize the updated data to send back
    serialize_data(&previous_data, tx_buf);

    // Send the updated data back
    if (HAL_SPI_TransmitReceive_IT(&hspi2, tx_buf, rx_buf, SPI_BUFFER_SIZE) != HAL_OK) {
        // Handle error
        printf("Error: SPI transmission failed.\n\r");
    }
}

void Handle_UART_TxRxCplt() {
	Data received_data;
	deserialize_data(rx_buf2, &received_data); // Deserialize received data

// Process the data based on the 'opp' field
	switch (received_data.opp) {
	case '+':
		received_data.result = received_data.x + received_data.y;
		break;
	case '-':
		received_data.result = received_data.x - received_data.y;
		break;
	case '*':
		received_data.result = received_data.x * received_data.y;
		break;
	case '/':
		if (received_data.y != 0) {
			received_data.result = received_data.x / received_data.y;
		} else {
			printf("Error: Division by zero\n");
			received_data.result = 0;  // Set result to 0 or handle as needed
		}
		break;
	default:
		printf("Error: Invalid operator\n");
		received_data.result = 0;  // Set result to 0 or handle as needed
		break;
	}

	serialize_data(&received_data, tx_buf2); // Serialize data to transmit

	if (HAL_UART_Transmit(&huart5, tx_buf2, sizeof(Data), HAL_MAX_DELAY) != HAL_OK){
		printf("Error: UART transmission failed.\n\r");
	} else {
		printf("\rSent data: x = %d, y = %d, opp = %d, result = %lu\n\r",
				received_data.x, received_data.y, received_data.opp,
				received_data.result);
	}

// Restart the receive process
	if(HAL_UART_Receive_IT(&huart5, rx_buf2, sizeof(Data))!= HAL_OK){
		printf("Error: UART transmission failed.\n\r");
	}
}



