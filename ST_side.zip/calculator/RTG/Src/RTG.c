#include "RTG.h"
#include "DATA.h"
#include "Funcs.h"

/****************************************
 *
 * UART5
 * PC12 TX  (CN8)
 * PD2  RX	(CN8)

 *
 * SPI2
 * PB10 SCK (CN10)
 * PC2 MISO (CN10)
 * PC3 MOSI (CN9)
 *
 **********************************************/


/**
 * @brief Buffers for SPI and UART communication.
 *
 * These buffers are used to transmit and receive data over SPI and UART.
 */
uint8_t *tx_buf; ///< Buffer for transmitting data over SPI.
uint8_t *rx_buf; ///< Buffer for receiving data over SPI.
uint8_t *tx_buf2; ///< Buffer for transmitting data over UART.
uint8_t *rx_buf2; ///< Buffer for receiving data over UART;

/**
 * @brief Stores the last transmitted data.
 *
 * This Data object holds the previous data that was sent.
 */
Data previous_data = {0};

/**
 * @brief Main function for the real-time generation (RTG) process.
 *
 * Initializes buffers, serializes data, and handles SPI and UART communication.
 * Allocates memory for buffers, performs communication, and handles errors.
 */
void rtg_main() {
    // Allocate memory for SPI and UART buffers
    tx_buf = (uint8_t *)malloc(SPI_BUFFER_SIZE);
    rx_buf = (uint8_t *)malloc(SPI_BUFFER_SIZE);
    tx_buf2 = (uint8_t *)malloc(UART_BUFFER_SIZE);
    rx_buf2 = (uint8_t *)malloc(UART_BUFFER_SIZE);

    // Check memory allocation success
    if (tx_buf == NULL || rx_buf == NULL || tx_buf2 == NULL || rx_buf2 == NULL) {
        // Handle memory allocation failure
        printf("Error: Memory allocation failed.\n\r");
        // Free any already allocated memory before returning
        free(tx_buf);
        free(rx_buf);
        free(tx_buf2);
        free(rx_buf2);
        return;
    }

    // Initialize data to be sent
    Data data_to_send = {0, 0, 0, 0}; // Example data (all fields set to 0)

    // Serialize data into the tx_buf
    serialize_data(&data_to_send, tx_buf);

    // Start SPI communication (transmit and receive)
    if (HAL_SPI_TransmitReceive_IT(&hspi2, tx_buf, rx_buf, SPI_BUFFER_SIZE) != HAL_OK) {
        // Handle SPI transmission error
        printf("Error: SPI transmission failed.\n\r");
    }

    // Start UART communication (receive)
    if (HAL_UART_Receive_IT(&huart5, rx_buf2, sizeof(Data)) != HAL_OK) {
        // Handle UART reception error
        printf("Error: UART reception failed.\n\r");
    }

    // Main loop with a low-power delay
    while (1) {
        HAL_Delay(LOW_POWER_DELAY); // Adjust delay duration as needed
    }

    // Free allocated memory (note: this code is not reached in the current loop setup)
    free(tx_buf);
    free(rx_buf);
    free(tx_buf2);
    free(rx_buf2);
}

/**
 * @brief  SPI Transmission and Reception Complete Callback.
 *         This function is called when the SPI transmission and reception is complete.
 * @param  hspi: Pointer to a SPI_HandleTypeDef structure that contains
 *               the configuration information for SPI module.
 * @retval None
 */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi) {
    if (hspi->Instance == SPI2) {
        Handle_SPI_TxRxCplt();
    }
}

/**
 * @brief  UART Reception Complete Callback.
 *         This function is called when the UART reception is complete.
 * @param  huart: Pointer to a UART_HandleTypeDef structure that contains
 *               the configuration information for UART module.
 * @retval None
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart->Instance == UART5) {
    	Handle_UART_TxRxCplt(); //
    }
}
/*
 void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi);
 void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi);
 void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi);
 void HAL_SPI_TxHalfCpltCallback(SPI_HandleTypeDef *hspi);
 void HAL_SPI_RxHalfCpltCallback(SPI_HandleTypeDef *hspi);
 void HAL_SPI_TxRxHalfCpltCallback(SPI_HandleTypeDef *hspi);
 void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi);
 void HAL_SPI_AbortCpltCallback(SPI_HandleTypeDef *hspi);
 */
