#ifndef DATA_H
#define DATA_H

#include <stdint.h>
#include "stm32f7xx_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/**
 * @brief Structure to hold data for SPI communication.
 */
typedef struct {
    int x; /**< X coordinate */
    int y; /**< Y coordinate */
    uint8_t opp; /**< Operation code */
    uint32_t result; /**< Result of the operation */
} Data;


extern Data previous_data;
#endif // DATA_H
