

/**
 * @brief Handle SPI transmission and reception completion.
 *
 * This function is called when SPI transmission and reception are complete.
 * It processes the received data, calculates results based on the operation code,
 * and sends the updated data back via SPI.
 */
extern void Handle_SPI_TxRxCplt(void);

/**
 * @brief Handle UART transmission and reception completion.
 *
 * This function processes data received over UART, calculates results based on the operation code,
 * and sends the updated data back via UART.
 */
extern void Handle_UART_TxRxCplt();

/**
 * @brief Serialize Data structure into a buffer.
 *
 * This function converts the `Data` structure into a byte buffer for transmission.
 *
 * @param data Pointer to the Data structure to be serialized.
 * @param buffer Pointer to the buffer where serialized data will be stored.
 */
extern void serialize_data(const Data* data, uint8_t* buffer);

/**
 * @brief Deserialize Data structure from a buffer.
 *
 * This function converts a byte buffer into a `Data` structure.
 *
 * @param buffer Pointer to the buffer containing the serialized data.
 * @param data Pointer to the Data structure where deserialized data will be stored.
 */
extern void deserialize_data(const uint8_t* buffer, Data* data);
