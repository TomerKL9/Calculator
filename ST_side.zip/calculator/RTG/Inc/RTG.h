/*
 * RTG.h
 *
 *  Created on: Oct 2, 2022
 *      Author: RTG
 *
 */
#ifndef INC_RTG_H_
#define INC_RTG_H_
#include "main.h"
#include "stm32f7xx_hal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern UART_HandleTypeDef huart3;
extern UART_HandleTypeDef huart5;
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern uint8_t *tx_buf;
extern uint8_t *rx_buf;
extern uint8_t *tx_buf2;
extern uint8_t *rx_buf2;


#define END_OF_STRING 0
#define BACKSPACE 8
#define LINE_FEED 10
#define CARRIAGE_RETURN 13

#define UART_DEBUG &huart3
#define SPI_1 &hspi1
#define SPI_2 &hspi2

#define GPIO_PER_1 GPIOB
#define GPIO_PER_2 GPIOB
#define GPIO_PER_3 GPIOB
#define GPIO_PER_4 GPIOC
#define GPIO_LED_1 LD1_Pin
#define GPIO_LED_2 LD2_Pin
#define GPIO_LED_3 LD3_Pin


#define SPI_BUFFER_SIZE sizeof(Data)
#define UART_BUFFER_SIZE sizeof(Data)
#define LOW_POWER_DELAY 300


void rtg_main();

#endif /* INC_RTG_H_ */
